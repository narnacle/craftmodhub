Auto-Messaging Skript for Minecraft
===================================

Description
-----------
The Auto-Messaging Skript is designed for Minecraft servers running with the Skript plugin. It automatically sends a random chat message to all players at regular intervals. You can use it to display important server information, reminders, or announcements to keep players engaged.

This Skript is highly customizable, allowing you to define your own messages and adjust the interval between messages.

Installation Instructions
-------------------------
1. Install Skript Plugin:
   - Make sure you have the Skript plugin installed on your server. You can download it from SkriptHub (https://www.skripthub.net) or from the official repository on GitHub.
   
2. Upload the Skript:
   - Download the auto-messaging.sk file.
   - Upload it to the plugins/Skript/scripts/ directory of your server.

3. Reload Skript:
   - In the Minecraft server, run the following command to reload the Skript:
     /sk reload auto-messaging

4. Check the Console:
   - After reloading, check the server console for a message confirming that the Skript has loaded successfully.
   - The server will start broadcasting random messages at the configured interval.

Configuration
-------------
The Skript is configured using the options: section at the top of the script.

1. Message Interval:
   - The default interval for messages is set to 300 seconds (5 minutes). This can be changed in the options: section:
     options:
         messageInterval: 300 seconds
     To change the interval, simply modify the messageInterval value (e.g., 600 seconds for 10 minutes).

2. Customizing Messages:
   - You can customize the messages that the Skript sends by editing the every {@messageInterval}: section in the script. 
   - Each message is a simple string that can include Minecraft color codes (e.g., &a for green, &b for blue).
     Example:
     set {_messages::*} to "&aWelcome to our server! Remember to read the rules!"
     set {_messages::*} to {_messages::*} and "&bCheck out our website at www.example.com!"
     set {_messages::*} to {_messages::*} and "&cDon't forget to vote for our server for awesome rewards!"

How it Works
------------
- The Skript runs at regular intervals defined by {@messageInterval}.
- The list of messages is randomly selected each time the interval is triggered.
- A random message is broadcasted to all players online using the broadcast "%{_randomMessage}%" command.
- The Skript ensures that the same message will not be shown repeatedly in a short period of time.

Troubleshooting
---------------
- Message Not Appearing:
  - Make sure Skript is installed and running correctly.
  - Ensure the script is located in the correct directory (plugins/Skript/scripts/).
  - Run the command /sk reload auto-messaging to reload the script after any edits.

- Error Messages:
  - If you see error messages, check the syntax in your auto-messaging.sk file. Make sure there are no indentation or syntax issues.
  - If you encounter any issues with message intervals or broadcasting, ensure that the Skript version you are using is up-to-date.

Support
-------
If you have any questions or need further assistance, feel free to reach out to the Skript community:
- Visit Skript Documentation (https://skriptlang.github.io/Skript/) for more information.
- Join the Skript Discord community for help from other users and developers.

Enjoy your Auto-Messaging Skript! 🎮