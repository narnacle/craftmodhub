Welcome Message Skript - README

===========================

Description:
-------------
This Skript sends a custom welcome message to new players when they join the server.
The message changes based on the time of day in the Minecraft world.

- If the time is before 12:00 (noon), it sends a "Good morning" message.
- If the time is after 12:00, it sends a "Good evening" message.

The Skript uses the player's world time to determine whether it's morning or evening.

===========================

Installation Instructions:
---------------------------
1. Make sure you have the Skript plugin installed on your server.
   - You can download it from https://www.spigotmc.org/resources/skript.77599/
   - Follow the installation instructions provided on the Skript page.

2. Place this Skript file (welcome-message.sk) into your "plugins/Skript/scripts" folder.

3. Reload or restart your server to load the Skript.
   - You can use the following command to reload Skript: `/sk reload welcome-message`.

===========================

Skript Features:
----------------
- Customizable welcome messages.
- Checks the time of day in the player's world to send an appropriate greeting.
- Sends the player a message and can also be modified to broadcast to all players.

Example Welcome Messages:
--------------------------
- "Good morning, [player]! Welcome to the server!"
- "Good evening, [player]! Welcome to the server!"

===========================

Customization:
--------------
You can modify the following parts of the Skript:
- The messages displayed to players in the `send` commands.
  Example: Change "&aGood morning, %player%! Welcome to the server!" to a custom message.
- Time-based conditions can be adjusted if you'd like to add more conditions (e.g., "Good night" after 6 PM).

===========================

Troubleshooting:
----------------
- If you encounter any issues, make sure that Skript is properly installed on your server.
- Ensure that the `welcome-message.sk` file is correctly placed in the `scripts` folder.
- If the Skript doesn't load, use the command `/sk reload welcome-message` to manually reload it.

===========================

Credits:
--------
Skript by: https://www.spigotmc.org/resources/skript.77599/
This Skript was created by Narnacle Digital.

===========================

Enjoy your personalized welcome messages!
